import json
from watson_developer_cloud import ToneAnalyzerV3
# import allows for the use of Watson's Tone Analyser API

tone_analyzer = ToneAnalyzerV3(
   username='46ccc874-dfb9-40d2-acd0-932a1058ccdb',
   password='Vyfxb7sx0u01',
   version='2016-05-19 ')
# login information required to use Watson's Tone Analyser API

def getaandd(str):
# define function 'getaandd'

    file = open('emotions.txt', 'w')
    # opens file to write tone analysis on comment

    file.write(json.dumps(tone_analyzer.tone(text=str), indent=0))
    file.close()
    # writes tone analysis to text file and closes

    file = 'emotions.txt'
    openFile = open(file,'r')
    # reopens file in order to extract "anger" and "disgust" data

    for line in openFile:
    # for loop goes through each line in text file

        if 'score' in line:
        # if case structure looks for string in each line of text

            anger = line
            # 'anger' is defined to be the line on which 'score' is found

            break
            # ends for loop

    anger = float(anger[9:15])
    # makes 'anger' a float number

    for line in openFile:
    # for loop goes through each line in text file

        if 'score' in line:
        # if case structure looks for string in each line of text

            disgust = line
            # 'disgust' is defined to be the line on which 'score' is found

            break
            # ends for loop

    disgust = float(disgust[9:15])
    # makes 'anger' a float number

    bullying = False
    # defines bullying as a boolean

    if anger > 0.75:
        bullying = True
    # if the tone recognition software detects 'anger' to be higher than 0.75, bullying is detected

    if disgust > 0.75:
        bullying = True
    # if the tone recognition software detects 'disgust' to be higher than 0.75, bullying is detected

    if anger > 0.5 and disgust > 0.5:
        bullying = True
    # if the tone recognition software detects 'anger' and 'disgust' to be higher than 0.5, bullying is detected

    openFile.close()
    # closes open text file

    return bullying
    # returns bullying which stores a boolean (whether or not the comment was calculated as harmful)
